# Parallel Coordinates Graph using D3 version 4

**Disclaimer**
This code is a modified version of Syntagmatic's [Parallel Coordinates](https://github.com/syntagmatic/parallel-coordinates).
Originally I just needed that code to work with D3 version 4 and saw that no plans to port the graph to version four were in
the works. I must give credit where credit is due, and thank syntagmatic and all the other contributors for all the hard work
they put into coding this complex and useful graph.

**License**
MIT, do whatever you want with this! I just hope it helps people out!


## Additional Features
Holding down the ctrl button will enable multi-brush mode. This will
allow the user to put multiple brushes on a single axis.
